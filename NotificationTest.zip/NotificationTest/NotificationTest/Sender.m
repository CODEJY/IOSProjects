//
//  Sender.m
//  NotificationTest
//  ss
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 2017/7/20.
//  Copyright © 2017年 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import "Sender.h"

@implementation Sender
-(void) sendNotification
{
    NSDictionary* dictionary = @{@"message":@"这是Notification发送的通知！"};
    [[NSNotificationCenter defaultCenter] postNotificationName:@"notificationMessage" object:nil userInfo:dictionary];
    
}
@end
