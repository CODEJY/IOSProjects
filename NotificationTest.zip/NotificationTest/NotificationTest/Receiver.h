//
//  Receiver.h
//  NotificationTest
//  ss
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 2017/7/20.
//  Copyright © 2017年 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Receiver : NSObject
@property (nonatomic,copy) NSString* message;
-(void) handleNotification: (NSNotification*) noti;
@end
