//
//  Receiver.m
//  NotificationTest
//  ss
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 2017/7/20.
//  Copyright © 2017年 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import "Receiver.h"

@implementation Receiver
@synthesize message;
-(id) init
{
    if (self = [super init]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNotification:) name:@"notificationMessage" object:nil];
    }
    return self;
}

-(void) handleNotification:(NSNotification *)noti
{
    NSDictionary* dictionary = [noti userInfo];
    message = dictionary[@"message"];
}
@end
