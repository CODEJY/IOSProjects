//
//  main.m
//  NotificationTest
//  ss
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 2017/7/20.
//  Copyright © 2017年 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Sender.h"
#import "Receiver.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Sender* sender = [[Sender alloc] init];
        Receiver* receiver = [[Receiver alloc] init];
        [sender sendNotification];
        NSLog(@"%@",receiver.message);
    }
    return 0;
}
