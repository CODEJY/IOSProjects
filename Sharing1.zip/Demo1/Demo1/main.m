//
//  main.m
//  Demo1
//  ARC的验证,如果animal和cat都是strong，会形成循环引用，把其中一个改为weak，就可以。正常执行会调用dealloc函数
//  Created by 吴佳雨 on 2017/7/13.
//  Copyright © 2017年 Gary. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Animal.h"
#import "Cat.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        Animal* animal = [[Animal alloc] init];
        Cat* cat = [[Cat alloc] init];
        animal.cat = cat;
        cat.animal = animal;
    }
    return 0;
}
