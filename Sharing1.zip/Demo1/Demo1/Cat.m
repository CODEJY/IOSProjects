//
//  Cat.m
//  Demo1
//
//  Created by 吴佳雨 on 2017/7/13.
//  Copyright © 2017年 Gary. All rights reserved.
//

#import "Cat.h"

@implementation Cat
@synthesize animal,name;
-(void) dealloc
{
    NSLog(@"Cat被销毁");
    if (animal == nil)
        NSLog(@"弱引用的animal被置为nil");
}

@end
