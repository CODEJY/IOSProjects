//
//  Cat.h
//  Demo1
//
//  Created by 吴佳雨 on 2017/7/13.
//  Copyright © 2017年 Gary. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Animal;
@interface Cat : NSObject
@property (nonatomic,strong) Animal* animal;
@property (nonatomic,assign) NSString* name;
@end
