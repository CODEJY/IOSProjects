//
//  Animal.h
//  Demo1
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 17/7/2017.
//  Copyright © 2017 Gary. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Cat;
@interface Animal : NSObject
@property (nonatomic,strong) Cat* cat;
@property (nonatomic,assign) NSString* name;
@end
