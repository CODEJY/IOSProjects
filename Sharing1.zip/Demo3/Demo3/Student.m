//
//  Student.m
//  MRCTest
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 13/7/2017.
//  Copyright © 2017 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import "Student.h"

@implementation Student
@synthesize university,grade,mArray;

-(float) averageGrade:(Student *)stu
{
    float avg = (self.grade+stu.grade)/2;
    return avg;
}
-(Student*) createNew: (NSString*) university_ addGrade: (float) grade_
{
    Student* stu = [[Student alloc] init];
    stu.university = university_;
    stu.grade = grade_;
    return [stu autorelease];
}

-(void) dealloc
{
    [mArray release];
    NSLog(@"Student:%@已经被销毁",self.university);
    [super dealloc];
}
@end
