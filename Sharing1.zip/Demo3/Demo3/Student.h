//
//  Student.h
//  MRCTest
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 13/7/2017.
//  Copyright © 2017 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import <Foundation/Foundation.h>
@interface Student : NSObject
@property (nonatomic,copy)NSString* university;
@property (nonatomic,retain)NSMutableArray* mArray;

@property (nonatomic,assign)float grade;
-(float) averageGrade: (Student*)stu;
-(Student*) createNew: (NSString*) universuty addGrade: (float) grade;
@end
