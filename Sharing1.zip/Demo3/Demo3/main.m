//
//  main.m
//  Demo3
//  MRC验证
//  Created by 吴佳雨 on 2017/7/13.
//  Copyright © 2017年 Gary. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"

int main(int argc, const char * argv[]) {
    
        NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
        Student* stu = [[Student alloc] init];
        stu.university = @"sysu";
    
        NSLog(@"目前引用计数：%lu",[stu retainCount]);
        Student* stu1 = [stu retain];
        NSLog(@"目前引用计数：%lu",[stu retainCount]);
        [stu release];
        NSLog(@"目前引用计数：%lu",[stu1 retainCount]);
        [stu1 release];
        [pool drain];
        return 0;
}
