//
//  Cat.m
//  Basic
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 14/7/2017.
//  Copyright © 2017 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import "Cat.h"

@implementation Cat
-(void) yell
{
   
    NSLog(@"Cat is yelling...");
}
-(void) askInterface
{
     
     NSLog(@"%@",varInterface);
}
-(void) eat
{
    NSLog(@"cat eat mouse.");
}
@end
