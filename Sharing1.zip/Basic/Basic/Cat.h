//
//  Cat.h
//  Basic
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 14/7/2017.
//  Copyright © 2017 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Animal.h"
#import "AnimalEat.h"
@class Dog;// 表明Dog是一个类，当只需要声明一个这个类的对象时，即不需要调用它里面的内容，可以用class，不用import整个.h文件
@interface Cat : Animal
-(void) yell;
-(void) askInterface;
-(void) eat;
@end
