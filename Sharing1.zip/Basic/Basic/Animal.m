//
//  Animal.m
//  Basic
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 14/7/2017.
//  Copyright © 2017 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import "Animal.h"
static int num;
@interface Animal ()
{
    NSString* extensionVar;
}

-(void) extensionMethod;
@end


@implementation Animal
{
    NSString* varInImp;
}

@synthesize name,age;

-(id) init
{
    if (self = [super init])
        num++;
    return self;
}

-(void) yell
{
    
    NSLog(@"Animal is yelling...");
}
-(void) setVarInterface:(NSString *)str
{
    self.varInterface = str;
}
+(void) getStatic
{
    NSLog(@"%i",num);
}
-(void) extensionMethod
{
    extensionVar = @"这是一个类扩展中的变量";
    NSLog(@"类扩展中的方法：%@",extensionVar);
}
-(void) callExtensionMethod
{
    [self extensionMethod];
}

-(void) testProtocol
{
    NSLog(@"协议验证成功");
}

-(id) copyWithZone:(NSZone *)zone
{
    Animal* newAnimal= [[Animal allocWithZone:zone] init];
    newAnimal.name = [self.name copy];
    newAnimal.age = age;
    return newAnimal;
}

-(id) mutableCopyWithZone:(NSZone *)zone
{
    Animal* newAnimal= [[Animal allocWithZone:zone] init];
    newAnimal.name = [self.name mutableCopy];
    newAnimal.age = age;
    return newAnimal;
}
-(void) changeName:(NSString *)name_ andAge:(int)age_
{
    self.name = name_;
    self.age = age_;
    NSLog(@"name:%@,age:%i",name,age);
}
@end
