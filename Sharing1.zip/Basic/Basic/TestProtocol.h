//
//  TestProtocol.h
//  Basic
//
//  Created by 吴佳雨 on 2017/7/16.
//  Copyright © 2017年 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TestProtocol
@required
-(void) testProtocol;
@optional
-(void) testOptionalMethod;
@end
