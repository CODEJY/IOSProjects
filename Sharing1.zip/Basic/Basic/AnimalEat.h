//
//  AnimalEat.h
//  Basic
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 14/7/2017.
//  Copyright © 2017 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Animal.h"
@interface Animal (AnimalEat)
-(void) eat;
//-(void) yell;//类别是可以覆盖主类中的方法，且拥有更高优先级，主类中的方法将不可用
@end
