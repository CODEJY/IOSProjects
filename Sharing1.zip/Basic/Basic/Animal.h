//
//  Animal.h
//  Basic
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 14/7/2017.
//  Copyright © 2017 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TestProtocol.h"
@interface Animal : NSObject <TestProtocol,NSCopying,NSMutableCopying>
{
     NSString*  varInterface;
     @public
     NSString* thePublic;
}
//objective-c中的方法都是默认公有的，不能对方法进行private等限定，可以通过类的扩展方式声明私有方法
-(id) init;
@property (nonatomic,copy,readwrite)NSString* name;//这里通常用copy，因为对于strong和copy，对于NSString不可变对象来说没有区别都是浅复制，而对于NSMutableString可变对象来说有区别，copy是深复制，strong是浅复制
@property (nonatomic,assign)int age;
-(void) yell;
-(void) setVarInterface: (NSString*) str;
+(void) getStatic;
-(void) callExtensionMethod;
-(void) changeName: (NSString*) name_ andAge: (int) age_;
@end
