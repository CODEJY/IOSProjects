//
//  main.m
//  Basic
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 14/7/2017.
//  Copyright © 2017 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Animal.h"
#import "Cat.h"
//extern int num;
//#import "AnimalEat.h"
//验证多态与id动态类型，以及重写函数，继承
void callYell(Animal* animal)
{ //Animal*改成id 可以说明id动态绑定特性
    [animal yell];
}

void thePolymorphism()
{
    Animal* animal = [[Animal alloc] init];
    Cat* cat = [[Cat alloc] init];
  //  [animal changeName:@"gary" andAge:23]; //调用多参数函数
    callYell(animal);
    callYell(cat);

}



//验证访问权限，在interface中与implement中的不同
void theAuthority()
{

    Cat* cat = [[Cat alloc] init];
    cat.name = @"BigCat";//@property类外访问
    [cat setVarInterface:@"protected访问成功"];
    cat->thePublic = @"public访问成功";//public访问方式不同，－>
    NSLog(@"%@",cat->thePublic);
    [cat askInterface];//子类可以继承父类interface中变量
}

//验证静态函数以及静态变量
void checkStatic()
{
    [Animal getStatic];
    Animal* a1 = [[Animal alloc] init];
    Animal* a2 = [[Animal alloc] init];
    a1.age = 10;//为了不警告
    a2.age = 11;
    
    [Animal getStatic];
}

//测试分类
void checkCategory()
{
    Animal* animal = [[Animal alloc] init];
    [animal eat];
    Cat* cat = [[Cat alloc] init];
    [cat eat];
}

//类的扩展，私有化
void theExtensionClass()
{
    Animal* animal = [[Animal alloc] init];
    [animal callExtensionMethod];
}


// 验证TestProtocol协议
void checkProtocol()
{
    Animal* animal = [[Animal alloc] init];
    [animal testProtocol];
}

// copy与mutableCopy,深复制与浅复制
void checkCopy()
{
    NSString* str = @"string";
    NSString* str1 = [str copy];
    NSMutableString* str2 = [str mutableCopy];
    NSLog(@"这是源不可变字符串的地址，str:%p",str);
    NSLog(@"这是copy的地址，str1:%p",str1);
    NSLog(@"这是mutableCopy的地址，str2:%p",str2);
    NSMutableString* mstr = [[NSMutableString alloc] initWithString:@"mutableString"];
    NSString* mstr1 = [mstr copy];
    NSMutableString* mstr2 = [mstr mutableCopy];
    NSLog(@"这是源可变字符串的地址，mstr:%p",mstr);
    NSLog(@"这是copy的地址，mstr1:%p",mstr1);
    NSLog(@"这是mutableCopy的地址，mstr2:%p",mstr2);
    //注意容器类对象
}

// 类的copy
void checkClassCopy()
{
    
    Animal* animal1 = [[Animal alloc] init];
    animal1.name = @"cat";
    animal1.age = 18;
    Animal* animal2 = [animal1 copy];
    animal2.name = @"dog";
    NSLog(@"Animal1.name:%@,age:%i,内存地址:%p",animal1.name,animal1.age,animal1);
    NSLog(@"Animal2.name:%@,age:%i,内存地址:%p",animal2.name,animal2.age,animal2);
}


//主程序入口
int main(int argc, const char * argv[])
{
    @autoreleasepool {
      thePolymorphism();//多态，继承，覆写
      //theAuthority();//验证访问权限
      //checkStatic();//静态函数与变量
      //checkCategory();//分类
      //theExtensionClass();//类的扩展
      //checkProtocol();//协议
      checkCopy();//copy与mutableCopy,深复制与浅复制
      //checkClassCopy();//类的copy协议
      //NSLog(@"%i",num);//全局变量
    }
    return 0;
}


