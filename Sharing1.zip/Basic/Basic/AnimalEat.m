//
//  AnimalEat.m
//  Basic
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 14/7/2017.
//  Copyright © 2017 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import "AnimalEat.h"

@implementation Animal (AnimalEat)
-(void) eat
{
    NSLog(@"Animal eats everything.");
}
/*-(void) yell
{
    NSLog(@"这是分类中的yell方法，覆盖了主类中的方法。Animal is yelling...");
}*/
@end
