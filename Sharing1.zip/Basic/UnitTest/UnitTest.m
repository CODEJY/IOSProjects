//
//  UnitTest.m
//  UnitTest
//
//  Created by GARY WU (MBC-ISD-OOCLL/ZHA) on 17/7/2017.
//  Copyright © 2017 GARY WU (MBC-ISD-OOCLL/ZHA). All rights reserved.
//

#import <XCTest/XCTest.h>
#import "Animal.h"
@interface UnitTest : XCTestCase
@property (nonatomic,strong)Animal* animal;
@end

@implementation UnitTest

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    self.animal = [[Animal alloc] init];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    self.animal = nil;
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    int n = [Animal getStatic];
    XCTAssertEqual(1+1, 1,"不相等！");
   
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
        for (int i = 0; i < 20; i++)
            printf("aaaaaa");
    }];
}


@end
